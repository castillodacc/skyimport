<?php

namespace Facebook\WebDriver\Exception;

class NoStringException extends WebDriverException
{
}
