<?php

namespace Laravel\BrowserKitTesting;

use PHPUnit_Framework_ExpectationFailedException;

class HttpException extends PHPUnit_Framework_ExpectationFailedException
{
    //
}
