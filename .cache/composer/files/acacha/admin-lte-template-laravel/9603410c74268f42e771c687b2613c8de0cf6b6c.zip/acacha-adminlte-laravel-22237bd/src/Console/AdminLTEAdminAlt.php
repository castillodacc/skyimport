<?php

namespace Acacha\AdminLTETemplateLaravel\Console;

use Illuminate\Console\Command;

/**
 * Class AdminLTEAdmin.
 */
class AdminLTEAdminAlt extends AdminLTEAdmin
{
    /**
     * The name and signature of the console command.
     */
    protected $signature = 'adminlte:admin';
}
