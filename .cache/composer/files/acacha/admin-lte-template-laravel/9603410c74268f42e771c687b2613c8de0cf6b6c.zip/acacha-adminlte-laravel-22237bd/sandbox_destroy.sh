#!/bin/bash
rm -rf sandbox


