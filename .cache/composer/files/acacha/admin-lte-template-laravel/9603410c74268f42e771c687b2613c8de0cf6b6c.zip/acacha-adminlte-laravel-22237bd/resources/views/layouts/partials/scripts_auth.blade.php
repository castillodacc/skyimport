<!-- Compiled app javascript -->
<script src="{{ url (mix('/js/app.js')) }}"></script>
