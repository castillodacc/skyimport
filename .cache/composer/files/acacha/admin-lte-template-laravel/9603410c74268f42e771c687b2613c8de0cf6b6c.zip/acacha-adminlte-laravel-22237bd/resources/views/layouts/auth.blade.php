<!DOCTYPE html>
<html>

@include('adminlte::layouts.partials.htmlheader')

@yield('content')

</html>